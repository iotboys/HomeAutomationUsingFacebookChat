﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IoTBoys.HomeAutomation.Models
{
    public class JsonResult
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public bool Success { get; set; }
    }
}