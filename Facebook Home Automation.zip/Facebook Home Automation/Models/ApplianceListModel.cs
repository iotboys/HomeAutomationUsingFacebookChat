﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IoTBoys.HomeAutomation.Models
{
    public class ApplianceListModel
    {
        public int ID { get; set; }
        public string ApplianceName { get; set; }
        
        public bool Status { get; set; }
    }
}