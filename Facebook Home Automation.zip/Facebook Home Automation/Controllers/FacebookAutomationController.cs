﻿using IoTBoys.HomeAutomation.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace IoTBoys.HomeAutomation.Controllers
{
    [RoutePrefix("api/FacebookAutomation")]
    public class FacebookAutomationController : ApiController
    { 
        [Route("ProcessCommand")]
        [HttpGet]
        public async Task<HttpResponseMessage> ProcessCommand()
        {
            string token = ConfigurationManager.AppSettings["Token"];
            string command = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://graph.facebook.com/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                Rootobject root = null;
                HttpResponseMessage response = await client.GetAsync("v2.10/1356724684425412?fields=conversations.limit(1){messages.limit(1){message}}&access_token=" + token);
                if (response.IsSuccessStatusCode)
                {
                   root = await response.Content.ReadAsAsync<Rootobject>();
                   command = root.conversations.data.First().messages.data.First().message;
                }
            }
            CommandModel cmd = new CommandModel();
            cmd.Command = command;
            return Request.CreateResponse(HttpStatusCode.OK, cmd);
        }
    }
}

public class Rootobject
{
    public Conversations conversations { get; set; }
    public string id { get; set; }
}

public class Conversations
{
    public Datum[] data { get; set; }
    public Paging paging { get; set; }
}

public class Paging
{
    public Cursors cursors { get; set; }
    public string next { get; set; }
}

public class Cursors
{
    public string before { get; set; }
    public string after { get; set; }
}

public class Datum
{
    public Messages messages { get; set; }
    public string id { get; set; }
}

public class Messages
{
    public Datum1[] data { get; set; }
    public Paging1 paging { get; set; }
}

public class Paging1
{
    public Cursors1 cursors { get; set; }
    public string next { get; set; }
}

public class Cursors1
{
    public string before { get; set; }
    public string after { get; set; }
}

public class Datum1
{
    public string message { get; set; }
    public string id { get; set; }
}
